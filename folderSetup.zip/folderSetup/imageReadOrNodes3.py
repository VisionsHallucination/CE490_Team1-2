"""
imageReadOrNodes2.py

Purpose:
- Prompt user for map selection + node coordinate definition (preset or user-defined)
- Load the map image from ./ImgMap/
- Report image size and rough world span scaling
- Identify valid lanes: "black pixels" are drivable
- Enforce safe drivable area: keep car center >= 0.09m from road edges
- Generate waypoint paths (~0.02m spacing) between nearby nodes using A* on the safe mask
- Print nodes ONCE after map selection
- Print waypoints ONCE immediately after nodes

This file does NOT modify any Quanser libraries.
"""

from __future__ import annotations

import os
import math
import heapq
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

import numpy as np
import cv2

XY = Tuple[float, float]


# ----------------------------
# Preset nodes (from your instructions)
# ----------------------------
SDCS_MapLayout_NODE_COORDS: Dict[int, XY] = {
    0: (0.000, -0.167),
    1: (0.265, -0.167),
    2: (1.113, -1.06),
    3: (1.067, -0.826),
    4: (2.204, -0.242),
    5: (1.966, -0.213),
    6: (0.958, 1.085),
    7: (1.274, 0.765),
    8: (-0.99, 1.06),
    9: (-0.902, 0.799),
    10: (-1.319, -0.485),
    11: (0.018, 2.021),
    12: (-0.003, 1.852),
    13: (0.284, 1.92),
    14: (2.225, 3.028),
    15: (1.959, 1.911),
    16: (0.903, 3.573),
    17: (1.495, 3.093),
    18: (0.536, 2.926),
    19: (0.84, 2.868),
    20: (-0.071, 4.414),
    21: (-0.075, 4.179),
    22: (-1.968, 2.653),
    23: (-1.685, 2.418),
}

SDCS_SmallMapLayout_NODE_COORDS: Dict[int, XY] = {
    0: (0.000, -0.167),
    1: (0.265, -0.167),
    2: (1.113, -1.06),
    3: (1.067, -0.826),
    4: (2.204, -0.242),
    5: (1.966, -0.213),
    6: (0.958, 1.085),
    7: (1.274, 0.765),
    8: (-0.99, 1.06),
    9: (-0.902, 0.799),
    10: (-1.319, -0.485),
}


# ----------------------------
# User prompt helpers (sequential, no “prompt blending”)
# ----------------------------
def _parse_xy(line: str) -> XY:
    parts = line.split(",")
    if len(parts) != 2:
        raise ValueError("Expected format: x, y")
    return float(parts[0].strip()), float(parts[1].strip())


def print_node_coords_once(node_coords: Dict[int, XY]) -> None:
    print("Your node coordinates are as follows:\n")
    for k in sorted(node_coords.keys()):
        x, y = node_coords[k]
        print(f"{k}: ({x:.3f}, {y:.3f}),")
    print("\n")


def print_waypoints_once(waypoints: List[XY]) -> None:
    print("Your calculated out waypoints are as follows:\n")
    for (x, y) in waypoints:
        print(f"({x:.3f}, {y:.3f}),")
    print("\n")


def prompt_map_and_nodes() -> Tuple[str, Dict[int, XY]]:
    """
    Implements your exact prompt behavior.
    Returns (resolved_map_name, node_coords).
    """
    aliases = {
        "sdcs_maplayout": "SDCS_MapLayout",
        "competition map": "SDCS_MapLayout",
        "competition": "SDCS_MapLayout",
        "sdcs_smallmaplayout": "SDCS_SmallMapLayout",
        "test map": "SDCS_SmallMapLayout",
        "test": "SDCS_SmallMapLayout",
    }

    map_in = input(
        'Please enter map file name (predefined maps are: "SDCS_SmallMapLayout", "test map", "SDCS_MapLayout", or "competition map"): \n> '
    ).strip()

    key = map_in.lower()
    resolved = aliases.get(key, map_in)

    # Normalize case for direct matches too
    if resolved.lower() == "sdcs_maplayout":
        resolved = "SDCS_MapLayout"
    if resolved.lower() == "sdcs_smallmaplayout":
        resolved = "SDCS_SmallMapLayout"

    if resolved == "SDCS_MapLayout":
        node_coords = dict(SDCS_MapLayout_NODE_COORDS)
        print_node_coords_once(node_coords)
        return resolved, node_coords

    if resolved == "SDCS_SmallMapLayout":
        node_coords = dict(SDCS_SmallMapLayout_NODE_COORDS)
        print_node_coords_once(node_coords)
        return resolved, node_coords

    # User-defined map
    n_nodes = int(
        input("Please enter number of nodes (program will start counting node number at 0): \n> ").strip()
    )

    print('Please enter coordinates of your following nodes (ex: 0.000, -0.167): \n')
    node_coords: Dict[int, XY] = {}
    for i in range(n_nodes):
        while True:
            try:
                line = input(f"node {i} > ").strip()
                node_coords[i] = _parse_xy(line)
                break
            except Exception:
                print('Invalid format. Please use x,y format with numbers (e.g., 0.5, 4.2).')

    print_node_coords_once(node_coords)
    return resolved, node_coords


# ----------------------------
# Map path / IO
# ----------------------------
def _this_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def resolve_map_image_path(map_name: str) -> str:
    base = map_name.strip()
    if "." not in os.path.basename(base):
        base = base + ".png"
    return os.path.join(_this_dir(), "ImgMap", base)


# ----------------------------
# Image vs World scaling report
# ----------------------------
@dataclass
class ScaleReport:
    width_px: int
    height_px: int
    world_min: XY
    world_max: XY
    world_span: XY
    approx_m_per_px: float


def analyze_image_vs_world(img_bgr: np.ndarray, node_coords: Dict[int, XY]) -> ScaleReport:
    h, w = img_bgr.shape[:2]
    pts = np.array(list(node_coords.values()), dtype=np.float64)

    world_min = (float(pts[:, 0].min()), float(pts[:, 1].min()))
    world_max = (float(pts[:, 0].max()), float(pts[:, 1].max()))
    world_span = (world_max[0] - world_min[0], world_max[1] - world_min[1])

    eps = 1e-9
    mpp_x = world_span[0] / max(w, eps)
    mpp_y = world_span[1] / max(h, eps)
    approx = float((abs(mpp_x) + abs(mpp_y)) / 2.0)

    return ScaleReport(
        width_px=w,
        height_px=h,
        world_min=world_min,
        world_max=world_max,
        world_span=world_span,
        approx_m_per_px=approx,
    )


# ----------------------------
# Lane mask: black pixels are drivable
# ----------------------------
@dataclass
class LaneMaskConfig:
    black_thresh: int = 70
    morph_kernel: int = 3
    open_iters: int = 1
    close_iters: int = 2


def build_drivable_mask_black(img_bgr: np.ndarray, cfg: LaneMaskConfig) -> np.ndarray:
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    drivable = (gray < cfg.black_thresh).astype(np.uint8) * 255

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (cfg.morph_kernel, cfg.morph_kernel))
    drivable = cv2.morphologyEx(drivable, cv2.MORPH_OPEN, k, iterations=cfg.open_iters)
    drivable = cv2.morphologyEx(drivable, cv2.MORPH_CLOSE, k, iterations=cfg.close_iters)
    return drivable


def build_safe_mask(drivable_mask: np.ndarray, margin_m: float, approx_m_per_px: float) -> np.ndarray:
    if approx_m_per_px <= 1e-9:
        approx_m_per_px = 0.01  # fallback
    margin_px = float(margin_m / approx_m_per_px)

    fg = (drivable_mask > 0).astype(np.uint8)
    dist = cv2.distanceTransform(fg, distanceType=cv2.DIST_L2, maskSize=3)
    safe = (dist >= margin_px).astype(np.uint8) * 255
    return safe


# ----------------------------
# World <-> Pixel mapping (bbox affine)
# ----------------------------
def world_to_pixel_bbox(x: float, y: float, rep: ScaleReport) -> Tuple[float, float]:
    xmin, ymin = rep.world_min
    xmax, ymax = rep.world_max
    wx = max(xmax - xmin, 1e-9)
    wy = max(ymax - ymin, 1e-9)

    u = (x - xmin) / wx * (rep.width_px - 1)
    v = (ymax - y) / wy * (rep.height_px - 1)  # invert y
    return u, v


def pixel_to_world_bbox(u: float, v: float, rep: ScaleReport) -> Tuple[float, float]:
    xmin, ymin = rep.world_min
    xmax, ymax = rep.world_max
    wx = max(xmax - xmin, 1e-9)
    wy = max(ymax - ymin, 1e-9)

    x = xmin + (u / max(rep.width_px - 1, 1e-9)) * wx
    y = ymax - (v / max(rep.height_px - 1, 1e-9)) * wy
    return x, y


# ----------------------------
# A* pathfinding on safe mask
# ----------------------------
def _heur(a: Tuple[int, int], b: Tuple[int, int]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _neighbors8(x: int, y: int) -> List[Tuple[int, int]]:
    return [
        (x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1),
        (x - 1, y - 1), (x - 1, y + 1), (x + 1, y - 1), (x + 1, y + 1),
    ]


def _snap_to_nearest_safe(mask: np.ndarray, p: Tuple[int, int], max_r: int = 25) -> Optional[Tuple[int, int]]:
    x0, y0 = p
    h, w = mask.shape[:2]
    for r in range(1, max_r + 1):
        for dy in range(-r, r + 1):
            for dx in (-r, r):
                x, y = x0 + dx, y0 + dy
                if 0 <= x < w and 0 <= y < h and mask[y, x] > 0:
                    return x, y
        for dx in range(-r, r + 1):
            for dy in (-r, r):
                x, y = x0 + dx, y0 + dy
                if 0 <= x < w and 0 <= y < h and mask[y, x] > 0:
                    return x, y
    return None


def astar_on_mask(mask: np.ndarray, start: Tuple[int, int], goal: Tuple[int, int]) -> Optional[List[Tuple[int, int]]]:
    h, w = mask.shape[:2]

    def inb(p): 
        x, y = p
        return 0 <= x < w and 0 <= y < h

    def ok(p):
        x, y = p
        return mask[y, x] > 0

    if not (inb(start) and inb(goal)):
        return None

    if not ok(start):
        start = _snap_to_nearest_safe(mask, start) or start
    if not ok(goal):
        goal = _snap_to_nearest_safe(mask, goal) or goal

    if not (ok(start) and ok(goal)):
        return None

    pq: List[Tuple[float, Tuple[int, int]]] = []
    heapq.heappush(pq, (0.0, start))

    came = {start: None}
    g = {start: 0.0}

    while pq:
        _, cur = heapq.heappop(pq)
        if cur == goal:
            break

        for nx, ny in _neighbors8(cur[0], cur[1]):
            nxt = (nx, ny)
            if not inb(nxt) or not ok(nxt):
                continue
            step = math.hypot(nx - cur[0], ny - cur[1])
            newg = g[cur] + step
            if nxt not in g or newg < g[nxt]:
                g[nxt] = newg
                f = newg + _heur(nxt, goal)
                heapq.heappush(pq, (f, nxt))
                came[nxt] = cur

    if goal not in came:
        return None

    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = came[cur]
    path.reverse()
    return path


def resample_path_pixels(path_px: List[Tuple[int, int]], step_px: float) -> List[Tuple[float, float]]:
    if not path_px:
        return []
    pts = np.array(path_px, dtype=np.float64)

    seg = np.sqrt(((pts[1:] - pts[:-1]) ** 2).sum(axis=1))
    s = np.concatenate([[0.0], np.cumsum(seg)])
    total = s[-1]
    if total < 1e-9:
        return [(float(pts[0, 0]), float(pts[0, 1]))]

    step_px = max(step_px, 1e-6)
    n = max(2, int(math.floor(total / step_px)) + 1)
    targets = np.linspace(0.0, total, n)

    out: List[Tuple[float, float]] = []
    j = 0
    for t in targets:
        while j < len(s) - 2 and s[j + 1] < t:
            j += 1
        t0, t1 = s[j], s[j + 1]
        p0, p1 = pts[j], pts[j + 1]
        if abs(t1 - t0) < 1e-9:
            out.append((float(p0[0]), float(p0[1])))
        else:
            a = (t - t0) / (t1 - t0)
            p = p0 + a * (p1 - p0)
            out.append((float(p[0]), float(p[1])))
    return out


# ----------------------------
# Waypoint generation: connect nearby nodes
# ----------------------------
def compute_waypoints_between_nodes(
    safe_mask: np.ndarray,
    node_coords: Dict[int, XY],
    rep: ScaleReport,
    waypoint_step_m: float = 0.02,
    neighbor_k: int = 3,
    max_neighbor_dist_m: float = 1.25,
) -> List[XY]:
    ids = sorted(node_coords.keys())
    pts = np.array([node_coords[i] for i in ids], dtype=np.float64)

    pairs = set()
    for i in range(len(ids)):
        dx = pts[:, 0] - pts[i, 0]
        dy = pts[:, 1] - pts[i, 1]
        dist = np.hypot(dx, dy)
        order = np.argsort(dist)

        picked = 0
        for j in order[1:]:
            if dist[j] > max_neighbor_dist_m:
                break
            a, b = ids[i], ids[int(j)]
            pair = (min(a, b), max(a, b))
            pairs.add(pair)
            picked += 1
            if picked >= neighbor_k:
                break

    step_px = float(waypoint_step_m / max(rep.approx_m_per_px, 1e-9))
    waypoints: List[XY] = []
    seen = set()

    for (a, b) in sorted(pairs):
        ax, ay = node_coords[a]
        bx, by = node_coords[b]
        au, av = world_to_pixel_bbox(ax, ay, rep)
        bu, bv = world_to_pixel_bbox(bx, by, rep)

        start = (int(round(au)), int(round(av)))
        goal = (int(round(bu)), int(round(bv)))

        path = astar_on_mask(safe_mask, start, goal)
        if path is None or len(path) < 2:
            continue

        sampled_uv = resample_path_pixels(path, step_px=step_px)
        for (u, v) in sampled_uv:
            x, y = pixel_to_world_bbox(u, v, rep)
            qx = int(round(x * 1000.0))
            qy = int(round(y * 1000.0))
            if (qx, qy) in seen:
                continue
            seen.add((qx, qy))
            waypoints.append((float(x), float(y)))

    return waypoints


# ----------------------------
# Public API: one-shot setup (prints once, returns data)
# ----------------------------
def select_map_build_nodes_and_waypoints(
    edge_margin_m: float = 0.09,
    waypoint_step_m: float = 0.02,
    debug_masks: bool = True,
) -> Tuple[str, Dict[int, XY], List[XY], dict]:
    """
    This is the ONE function Setup_Real_Scenario calls.

    It:
      1) prompts for map + nodes (once)
      2) prints node coords (once)
      3) loads image + prints size vs world span
      4) builds drivable/safe masks
      5) computes and prints waypoints (once)
      6) returns everything for the main program to use
    """
    map_name, node_coords = prompt_map_and_nodes()

    img_path = resolve_map_image_path(map_name)
    img = cv2.imread(img_path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Could not read map image at: {img_path}")

    rep = analyze_image_vs_world(img, node_coords)

    print(f"[Map Info] Loaded: {img_path}")
    print(f"[Map Info] Image size (px): width={rep.width_px}, height={rep.height_px}")
    print(f"[Map Info] World bbox min={rep.world_min}, max={rep.world_max}")
    print(f"[Map Info] World span (m): dx={rep.world_span[0]:.3f}, dy={rep.world_span[1]:.3f}")
    print(f"[Map Info] Approx meters-per-pixel: {rep.approx_m_per_px:.6f}\n")

    drivable = build_drivable_mask_black(img, LaneMaskConfig())
    safe = build_safe_mask(drivable, margin_m=edge_margin_m, approx_m_per_px=rep.approx_m_per_px)

    if debug_masks:
        out_dir = os.path.join(_this_dir(), "debug_node_extraction")
        os.makedirs(out_dir, exist_ok=True)
        cv2.imwrite(os.path.join(out_dir, "drivable_black_mask.png"), drivable)
        cv2.imwrite(os.path.join(out_dir, "safe_mask_margin.png"), safe)

    waypoints = compute_waypoints_between_nodes(
        safe_mask=safe,
        node_coords=node_coords,
        rep=rep,
        waypoint_step_m=waypoint_step_m,
        neighbor_k=3,
        max_neighbor_dist_m=1.25,
    )

    print_waypoints_once(waypoints)

    meta = {
        "map_image_path": img_path,
        "image_width_px": rep.width_px,
        "image_height_px": rep.height_px,
        "world_min": rep.world_min,
        "world_max": rep.world_max,
        "world_span": rep.world_span,
        "approx_m_per_px": rep.approx_m_per_px,
        "edge_margin_m": edge_margin_m,
        "waypoint_step_m": waypoint_step_m,
        "num_waypoints": len(waypoints),
    }
    return map_name, node_coords, waypoints, meta


def print_nodes_and_waypoints(node_coords, waypoints):
    # prints (no prompts, no returns)
    print("Your node coordinates are as follows:\n")
    for k in sorted(node_coords.keys()):
        x, y = node_coords[k]
        print(f"{k}: ({x:.3f}, {y:.3f}),")
    print("\n")

    print("Your calculated out waypoints are as follows:\n")
    for (x, y) in waypoints:
        print(f"({x:.3f}, {y:.3f}),")
    print("\n")